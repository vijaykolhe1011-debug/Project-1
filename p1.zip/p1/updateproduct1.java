package com.s1;

import com.s1.connection;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@MultipartConfig(maxFileSize = 16177216)
public class updateproduct1 extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        int id = Integer.parseInt(request.getParameter("p_id"));
        String name = request.getParameter("p_name");
        Double price = Double.parseDouble(request.getParameter("p_price"));
        int quan = Integer.parseInt(request.getParameter("p_quan"));
        int cid = Integer.parseInt(request.getParameter("catname"));
        int bid = Integer.parseInt(request.getParameter("brandname"));
        String desc = request.getParameter("p_desc");

        PrintWriter out = response.getWriter();
        Part part = request.getPart("p_image");
        String fileName = extractFilename(part);
        String savePath = "C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image" + File.separator + fileName;

        File fileSaveDir = new File(savePath);
        part.write(savePath + File.separator);

        int result = 0;

        try {
            connection c = new connection();
            Connection c1 = c.DBcon();
            String query = "UPDATE product SET pname=?, price=?, quantity=?, cid=?, bid=?, description=?, filename=?";
            if (part != null && part.getSize() > 0) {
                query += ", image=?";
            }
            query += " WHERE pid=?";

            PreparedStatement ps = c1.prepareStatement(query);
            ps.setString(1, name);
            ps.setDouble(2, price);
            ps.setInt(3, quan);
            ps.setInt(4, cid);
            ps.setInt(5, bid);
            ps.setString(6, desc);
            ps.setString(7, fileName);

            //int parameterIndex = 8;
            if (part != null && part.getSize() > 0) {
                ps.setString(8, savePath);
                //parameterIndex = 9;
            }
            ps.setInt(9, id);

            result = ps.executeUpdate();
            c1.close();

            if (result > 0) {
                RequestDispatcher rd = request.getRequestDispatcher("viewproducts.jsp");
                rd.include(request, response);
            } else {
                response.sendRedirect("index.html");
            }
        } catch (Exception e) {
            out.print("Error: " + e.getMessage());
        }
    }

    private String extractFilename(Part part) {
        String contentDisposition = part.getHeader("content-disposition");
        String[] items = contentDisposition.split(";");
        for (String item : items) {
            if (item.trim().startsWith("filename")) {
                return item.substring(item.indexOf('=') + 2, item.length() - 1);
            }
        }
        return "";
    }
}
