package com.s1;


import javax.servlet.http.Part;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kiran
 */
public class extimgpath {
     public  String extractFilename(Part part) {
                String contentDisposition = part.getHeader("content-disposition");
                String[] items = contentDisposition.split(";");
                for (String item : items) {
                    if (item.trim().startsWith("filename")) {
                        return item.substring(item.indexOf('=') + 2, item.length() - 1);
                    }
                }
                return "";
            }

    
}
