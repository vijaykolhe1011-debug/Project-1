-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: localhost    Database: onlinelaptopshop
-- ------------------------------------------------------
-- Server version	8.0.40

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `pid` int NOT NULL AUTO_INCREMENT,
  `pname` varchar(500) NOT NULL,
  `price` double NOT NULL,
  `quantity` int NOT NULL,
  `cid` int NOT NULL,
  `bid` int NOT NULL,
  `image` varchar(500) NOT NULL,
  `description` varchar(500) NOT NULL,
  `filename` varchar(45) NOT NULL,
  PRIMARY KEY (`pid`),
  KEY `_idx` (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'Hp 1',500000,39,101,202,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\wallpaper4.jpg','HP 15s 11th generation 16gb ram and 512 gb ssd','wallpaper4.jpg'),(2,'Hp 15s',49999,-49911,101,201,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\hp15s.jpg','HP laptop 15s 11th Gen Intel Core i5-1155g7 15.6 inch display','hp15s.jpg'),(3,'HP 250',62000,49,102,201,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\hp250g9.jpg','Buy HP 250 G9 15.6 inch Notebook | Supreme Computers','hp250g9.jpg'),(4,'DELL ',55000,59,102,202,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\Delli5.jpg','Dell Intel Core i5 12.5 inch Full HD Laptop on Hire','Delli5.jpg'),(5,'dell new',40000,12,101,202,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\dellnewin.jpg','Dell new Insipiron i3583 15.6 \"HD Touch-screen Laptop','dellnewin.jpg'),(6,'dell',60000,44,101,202,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\dell-1o35g1.jpg','Dell inspiron 15.6-inch Full HD Touch-screen Intel-i5-1035G1','dell-1o35g1.jpg'),(7,'Lenovo1',48000,26,103,203,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\lenovo2dimm.jpg','Lenovo Laptop Computer Memory size :32gb Ddr ','lenovo2dimm.jpg'),(8,'Lenovo2',58000,33,102,203,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\lenovoideapad3.jpg','Lenovo Ideapad 3 Intel Celeron N4020 Laptop','lenovoideapad3.jpg'),(9,'lenovo3',50000,33,103,203,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\lenovoip.jpg','Lenovo IP SLIM3 VWIN Laptop ','lenovoip.jpg'),(10,'Hp ',50000,100,101,201,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\download.jpeg','HP 15s AMD Ryzen 3 Quad Core 7320U - (8 GB/512 GB SSD/Windows 11 Home) 15-fc0026AU Thin and Light Laptop  (15.6 Inch, Natural Silver, 1.59 kg, With MS Office)','download.jpeg'),(11,'Hp ',51000,100,102,201,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\hp i5','HP Intel Core i5 12th Gen 1235U - (16 GB/512 GB SSD/Windows 11 Home) 15s-fq5330TU|15-fd0111TU Thin and Light Laptop  (15.6 inch, Silver, 1.69 Kg, With MS Office)','hp i5'),(12,'hp',54000,98,103,201,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\hp g13.webp','HP Intel Core i5 13th Gen 1334U - (16 GB/512 GB SSD/Windows 11 Home) 15-fd0315TU Thin and Light Laptop  (15.5 Inch, Natural Silver, 1.59 Kg, With MS Office)','hp g13.webp'),(13,'DELL ',43000,100,101,202,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\dell i.webp','DELL Inspiron 3530 Intel Core i3 13th Gen 1305U - (8 GB/1 TB SSD/Windows 11 Home) Inspiron 3530 Thin and Light Laptop  (15.6 Inch, Silver, 1.65 Kg, With MS Office)','dell i.webp'),(14,'DELL ',71000,100,102,202,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\dell i.jpeg','DELL Inspiron 7440 2-in-1 Intel Core i5 13th Gen 1334U - (16 GB/512 GB SSD/Windows 11 Home) Inspiron 14 2-in-1 2 in 1 Laptop  (14 Inch, Ice Blue, 1.71 Kg, With MS Office)','dell i.jpeg'),(15,'DELL ',71000,100,103,202,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\dell ry.webp','DELL inspiron 15 AMD Ryzen 5 Quad Core 7520U - (8 GB/512 GB SSD/Windows 11 Home) Inspiron 3535 Laptop Laptop  (15.6 inch, Platinum Silver, 1.63 kg, With MS Office)','dell ry.webp'),(16,'Lenovo1',40000,100,101,203,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\lenovo-v14.webp','Lenovo V14 Intel Core i5 12th Gen 1235U - (16 GB/512 GB SSD/Windows 11 Home) V 14 Thin and Light Laptop  (14.1 inch, Iron Grey)','lenovo-v14.webp'),(17,'Lenovo1',50000,100,102,203,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\v-14-i5.webp','Lenovo V 14 (2025) Intel Core i5 12th Gen 1235U - (16 GB/512 GB SSD/Windows 11 Home) V 14 Thin and Light Laptop  (14 inch, Iron Gray, 1.5 kg, With MS Office)','v-14-i5.webp'),(18,'Lenovo1',50000,100,103,203,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\lenovo i5 slim 3.webp','Lenovo IdeaPad Slim 3 Intel Core i5 12th Gen 12450H - (16 GB/512 GB SSD/Windows 11 Home) 14IAH8 Thin and Light Laptop  (14 Inch, Arctic Grey, 1.37 Kg, With MS Office)','lenovo i5 slim 3.webp'),(19,'MAC',92000,100,101,205,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\apple.avif','Apple MacBook AIR Apple M2 - (8 GB/512 GB SSD/Mac OS Monterey) MLXX3HN/A  (13.6 Inch, Space Grey, 1.24 Kg)','apple.avif'),(20,'MAC',91000,100,102,205,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\applw.jpg','Apple MacBook AIR Apple M2 - (16 GB/256 GB SSD/macOS Sequoia) MC7X4HN/A  (13.6 Inch, Midnight, 1.24 kg)','applw.jpg'),(21,'MAC',166000,100,103,205,'C:\\Users\\Kiran\\Documents\\NetBeansProjects\\ddd\\web\\image\\macbook.webp','Apple Apple M4 - (16 GB/512 GB SSD/macOS Sequoia) MW2U3HN/A  (14 Inch, Space Black, 1.55 kg)','macbook.webp');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-21 22:46:52
