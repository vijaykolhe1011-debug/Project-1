/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.s1;

import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Kiran
 */
public class connection {
    public Connection DBcon() throws ClassNotFoundException
    {
        Connection con=null;
        
        try{
    
    Class.forName("com.mysql.cj.jdbc.Driver");
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/onlinelaptopshop", "root", "1234");
        }
        catch(Exception e)
        {
            System.out.print(e);
        }
    return con;
    }
}
